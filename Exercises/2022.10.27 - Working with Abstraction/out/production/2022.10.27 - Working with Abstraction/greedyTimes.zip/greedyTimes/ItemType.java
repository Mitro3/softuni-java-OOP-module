package greedyTimes;

public enum ItemType {
    GOLD,
    CASH,
    GEM
}
